package com.kmit.shoppingcart.controller;

import java.util.List;

import org.springframework.web.client.RestTemplate;

public class UpdateFeaturesController {
	public String updateFeaturesURI="";
	 List<Integer> updateFeatures(String user_name)
	{
		updateFeaturesURI="http://localhost:8080/BRS/updateRatingFeatures/"+user_name;
		RestTemplate rt=new RestTemplate();
		List<Integer> featuresList=rt.getForObject(updateFeaturesURI,List.class);
		return featuresList;
	}
}
