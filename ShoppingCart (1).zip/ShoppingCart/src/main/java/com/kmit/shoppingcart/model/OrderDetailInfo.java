package com.kmit.shoppingcart.model;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.kmit.shoppingcart.entity.Order;
import com.kmit.shoppingcart.entity.OrderDetail;

public class OrderDetailInfo {
private String id;

private String productCode;
private String productName;

private int quanity;
private double price;
private double amount;
private String orderStatus;



public OrderDetailInfo() {

}

// Using for Hibernate Query.
// Sử dụng cho Hibernate Query.
public OrderDetailInfo(String id, String productCode, //
String productName, int quanity, double price, double amount,String orderStatus) {
this.id = id;
this.productCode = productCode;
this.productName = productName;
this.quanity = quanity;
this.price = price;
this.amount = amount;
this.orderStatus=orderStatus;
}

public String getId() {
return id;
}

public void setId(String id) {
this.id = id;
}

public String getProductCode() {
return productCode;
}

public void setProductCode(String productCode) {
this.productCode = productCode;
}

public String getProductName() {
return productName;
}

public void setProductName(String productName) {
this.productName = productName;
}

public int getQuanity() {
return quanity;
}

public void setQuanity(int quanity) {
this.quanity = quanity;
}

public double getPrice() {
return price;
}

public void setPrice(double price) {
this.price = price;
}

public double getAmount() {
return amount;
}

public void setAmount(double amount) {
this.amount = amount;
}


public String getOrderStatus() {
	return orderStatus;
}

public void setOrderStatus(String orderStatus) {
	this.orderStatus = orderStatus;
}


}