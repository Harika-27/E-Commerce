package com.kmit.shoppingcart.dao;

import com.kmit.shoppingcart.entity.Account;

public interface AccountDAO {


public Account findAccount(String userName );

}