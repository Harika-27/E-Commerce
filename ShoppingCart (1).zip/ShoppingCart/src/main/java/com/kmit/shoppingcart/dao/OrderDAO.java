package com.kmit.shoppingcart.dao;

import java.util.List;

import com.kmit.shoppingcart.model.CartInfo;
import com.kmit.shoppingcart.model.OrderDetailInfo;
import com.kmit.shoppingcart.model.OrderInfo;
import com.kmit.shoppingcart.model.PaginationResult;

public interface OrderDAO {

public void saveOrder(CartInfo cartInfo);

public PaginationResult<OrderInfo> listOrderInfo(int page,
int maxResult, int maxNavigationPage,String uname);

public OrderInfo getOrderInfo(String orderId);

public int setCustomerStatus(String s,String id);

public List<OrderDetailInfo> listOrderDetailInfos(String orderId);

}