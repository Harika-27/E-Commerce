package com.kmit.shoppingcart.dao.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import com.kmit.shoppingcart.dao.OrderDAO;
import com.kmit.shoppingcart.dao.ProductDAO;
import com.kmit.shoppingcart.entity.Order;
import com.kmit.shoppingcart.entity.OrderDetail;
import com.kmit.shoppingcart.entity.Product;
import com.kmit.shoppingcart.model.CartInfo;
import com.kmit.shoppingcart.model.CartLineInfo;
import com.kmit.shoppingcart.model.CustomerInfo;
import com.kmit.shoppingcart.model.OrderDetailInfo;
import com.kmit.shoppingcart.model.OrderInfo;
import com.kmit.shoppingcart.model.PaginationResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

//Transactional for Hibernate
@Transactional
public class OrderDAOImpl implements OrderDAO {

@Autowired
private SessionFactory sessionFactory;

@Autowired
private ProductDAO productDAO;

private int getMaxOrderNum() {
String sql = "Select max(o.orderNum) from " + Order.class.getName() + " o ";
Session session = sessionFactory.getCurrentSession();
Query query = session.createQuery(sql);
Integer value = (Integer) query.uniqueResult();
if (value == null) {
return 0;
}
return value;
}

@Override    
public void saveOrder(CartInfo cartInfo) {
Session session = sessionFactory.getCurrentSession();

int orderNum = this.getMaxOrderNum() + 1;
Order order = new Order();

order.setId(UUID.randomUUID().toString());
order.setOrderNum(orderNum);
order.setOrderDate(new Date());
order.setAmount(cartInfo.getAmountTotal());
order.setOrderStatus("dispatched");
order.setCustomerOrderStatus("inprogress");;


CustomerInfo customerInfo = cartInfo.getCustomerInfo();
order.setCustomerName(customerInfo.getName());
order.setCustomerEmail(customerInfo.getEmail());
order.setCustomerPhone(customerInfo.getPhone());
order.setCustomerAddress(customerInfo.getAddress());
order.setCustomerPaymentOptions(customerInfo.getPayment_options());
order.setBuyer_id(customerInfo.getId());

session.persist(order);

List<CartLineInfo> lines = cartInfo.getCartLines();

for (CartLineInfo line : lines) {
OrderDetail detail = new OrderDetail();
detail.setId(UUID.randomUUID().toString());
detail.setOrder(order);
detail.setAmount(line.getAmount());
detail.setPrice(line.getProductInfo().getPrice());
detail.setQuanity(line.getQuantity());
detail.setOrderStatus("dispatched");

String code = line.getProductInfo().getCode();
Product product = this.productDAO.findProduct(code);
detail.setProduct(product);

session.persist(detail);
}

// Set OrderNum for report.
// Set OrderNum để thông báo cho người dùng.
cartInfo.setOrderNum(orderNum);
}

// @page = 1, 2, ...
@Override
public PaginationResult<OrderInfo> listOrderInfo(int page, int maxResult, int maxNavigationPage,String uname) {
String sql = "Select new " + OrderInfo.class.getName()//
+ "(ord.id, ord.orderDate, ord.orderNum, ord.amount, "
+ " ord.customerName, ord.customerAddress, ord.customerEmail, ord.customerPhone,ord.orderStatus,ord.customerOrderStatus) " + " from "
+ Order.class.getName() + " ord "//
+ " where ord.buyer_id='"+uname+"'"
+ " order by ord.orderNum desc";
Session session = this.sessionFactory.getCurrentSession();

Query query = session.createQuery(sql);

return new PaginationResult<OrderInfo>(query, page, maxResult, maxNavigationPage);
}

public Order findOrder(String orderId) {
Session session = sessionFactory.getCurrentSession();
Criteria crit = session.createCriteria(Order.class);
crit.add(Restrictions.eq("id", orderId));
return (Order) crit.uniqueResult();
}
public int  setCustomerStatus(String s,String orderId) {
	Session session =this.sessionFactory.getCurrentSession();
	Order o= this.findOrder(orderId);
	o.setCustomerOrderStatus(s);
	Calendar cal=Calendar.getInstance();
	Date orderDate=cal.getTime();
	o.setOrderDate(orderDate);
	return 0;
}

@Override
public OrderInfo getOrderInfo(String orderId) {
Order order = this.findOrder(orderId);
if (order == null) {
return null;
}
return new OrderInfo(order.getId(), order.getOrderDate(), //
order.getOrderNum(), order.getAmount(), order.getCustomerName(), //
order.getCustomerAddress(), order.getCustomerEmail(), order.getCustomerPhone(),order.getOrderStatus(),order.getCustomerOrderStatus());
}

@Override
public List<OrderDetailInfo> listOrderDetailInfos(String orderId) {
String sql = "Select new " + OrderDetailInfo.class.getName() //
+ "(d.id, d.product.code, d.product.name , d.quanity,d.price,d.amount,d.orderStatus) "//
+ " from " + OrderDetail.class.getName() + " d "//
+ " where d.order.id = :orderId ";

Session session = this.sessionFactory.getCurrentSession();

Query query = session.createQuery(sql);
query.setParameter("orderId", orderId);

return query.list();
}

}